extends Node3D
var server = "01"
var money = 150000
var speed = 0.0

func _ready():
    $UI/Server.text = "СЕРВЕР " + server
    $UI/Money.text = "Баланс: ₽%s" % money
    $UI/Info.text = "Тестовый режим • Арзамас"
    $Player.position = Vector3(0, 1, 0)

func choose_server(id):
    server = id
    $UI/Server.text = "СЕРВЕР " + server
    $UI/Info.text = "Подключено к серверу " + server

func _process(delta):
    var dir = Vector3.ZERO
    if Input.is_action_pressed("forward"): dir.z -= 1
    if Input.is_action_pressed("back"): dir.z += 1
    if Input.is_action_pressed("left"): dir.x -= 1
    if Input.is_action_pressed("right"): dir.x += 1
    if dir.length() > 0:
        $Player.position += dir.normalized() * 5.0 * delta
